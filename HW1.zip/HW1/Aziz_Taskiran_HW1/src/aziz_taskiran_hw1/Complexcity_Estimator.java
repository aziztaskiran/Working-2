package aziz_taskiran_hw1;
import java.util.Random;
public class Complexcity_Estimator 
        
{
    public int[] dizi2;
    public Complexcity_Estimator(int[] dizi3)
    {
        
        dizi2=dizi3;
    }
    
    public void Evaluate()
    {
        Random rnd = new Random();
         
        
        int m,k,t,n,g;
        System.out.println("Now Integer Arrays will be sorted");
        for(g=0;g<dizi2.length;g++)
        {
          int[] dizi = new int[dizi2[g]];
          for(n=0;n<dizi2[g];n++)
          {
            dizi[n]=rnd.nextInt();
          }
          
          long first=System.currentTimeMillis();
          for(k=1;k<dizi.length;k++)
          {
              t=dizi[k];
              m=k-1;
              while(m>=0 && t<dizi[m])
              {
                  dizi[m+1]=dizi[m];
                  m--;
              }
                  dizi[m+1]=t;
          }
          long last=System.currentTimeMillis();
          long x = last-first;
          System.out.println("Time to sort "+dizi2[g]+" elements integer array:"+x+" milliseconds");
         

        }
        float c;
        int d,e,b,a;
        System.out.println("Now Float Arrays will be sorted");
        for(e=0;e<dizi2.length;e++)
        {
          float[] dizi1 = new float[dizi2[e]];
          for(d=0;d<dizi2[e];d++)
          {
            dizi1[d]=rnd.nextInt();
          }
          
          long ilk = System.currentTimeMillis();
          for(b=1;b<dizi1.length;b++)
          {
              c=dizi1[b];
              a=b-1;
              while(a>=0 && c<dizi1[a])
              {
                  dizi1[a+1]=dizi1[a];
                  a--;
              }
                  dizi1[a+1]=c;
          }
          long son=System.currentTimeMillis();
         
          long x = son-ilk;
          System.out.println("Time to sort "+dizi2[e]+" elements float array:"+x+" milliseconds");
        }
          
        
    
    }
    
    public static void main(String[] args)
    {
        int[] myarray={100,1000,10000,20000,30000,40000,50000,60000};
        Complexcity_Estimator myEstimate = new Complexcity_Estimator(myarray);
        myEstimate.Evaluate();
    }
        
        
}


          
          